package com.sradszone.camon30ssensi

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    private val names = listOf(
        "General", "Red Dot", "2x Scope", "4x Scope", "Sniper Scope", "Free Look"
    )
    private val defaults = intArrayOf(190, 185, 175, 160, 95, 150)
    private val sliders = mutableListOf<SeekBar>()
    private lateinit var values: IntArray
    private val bg = Color.rgb(12, 15, 25)
    private val card = Color.rgb(25, 31, 48)
    private val accent = Color.rgb(255, 177, 36)
    private val prefs by lazy { getSharedPreferences("sensi_settings", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        values = IntArray(names.size) { i -> prefs.getInt(names[i], defaults[i]) }
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val brand = TextView(this).apply {
            text = "🔥 SR ADS ZONE"
            textSize = 25f
            setTextColor(accent)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(4))
        }
        content.addView(brand)

        val title = TextView(this).apply {
            text = "CAMON 30S • FREE FIRE SENSI"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(8))
        }
        content.addView(title)

        val note = TextView(this).apply {
            text = "Starting profile only — adjust in training mode to find what feels right."
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(4), dp(4), dp(16))
        }
        content.addView(note)

        sliders.clear()
        names.forEachIndexed { i, name ->
            val panel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(10), dp(14), dp(10))
                setBackgroundColor(card)
            }
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            val label = TextView(this).apply {
                text = name
                textSize = 16f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
            }
            val value = TextView(this).apply {
                text = values[i].toString()
                textSize = 17f
                setTextColor(accent)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.END
            }
            line.addView(label, LinearLayout.LayoutParams(0, dp(28), 1f))
            line.addView(value, LinearLayout.LayoutParams(dp(50), dp(28)))
            panel.addView(line)

            val seek = SeekBar(this).apply {
                max = 200
                progress = values[i].coerceIn(0, 200)
                progressTintList = android.content.res.ColorStateList.valueOf(accent)
                thumbTintList = android.content.res.ColorStateList.valueOf(accent)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                        values[i] = progress
                        value.text = progress.toString()
                    }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {
                        prefs.edit().putInt(name, values[i]).apply()
                    }
                })
            }
            sliders.add(seek)
            panel.addView(seek)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.bottomMargin = dp(10)
            content.addView(panel, lp)
        }

        val save = Button(this).apply {
            text = "SAVE PROFILE"
            setTextColor(Color.BLACK)
            setBackgroundColor(accent)
            setOnClickListener {
                val edit = prefs.edit()
                names.forEachIndexed { i, name -> edit.putInt(name, values[i]) }
                edit.apply()
                Toast.makeText(this@MainActivity, "Sensi profile saved on this phone.", Toast.LENGTH_SHORT).show()
            }
        }
        content.addView(save, fullWidth())

        val reset = Button(this).apply {
            text = "RESET STARTING PROFILE"
            setOnClickListener {
                values = defaults.copyOf()
                names.indices.forEach { i -> sliders[i].progress = values[i] }
                val edit = prefs.edit()
                names.forEachIndexed { i, name -> edit.putInt(name, values[i]) }
                edit.apply()
                Toast.makeText(this@MainActivity, "Starting profile restored.", Toast.LENGTH_SHORT).show()
            }
        }
        content.addView(reset, fullWidth())

        val footer = TextView(this).apply {
            text = "Note: This app does not change Free Fire automatically. Enter the values manually in the game's settings. Results vary by player and update."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(dp(4), dp(12), dp(4), dp(20))
        }
        content.addView(footer)

        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
    }

    private fun fullWidth(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(8)
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
